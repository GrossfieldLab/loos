This directory stores tarballs of the source, which will be used conda-forge.
