var class_voronoi_1_1_region =
[
    [ "__init__", "class_voronoi_1_1_region.html#aa151a072354d536924bc5c6ba0735cb3", null ],
    [ "__str__", "class_voronoi_1_1_region.html#a36346b79c2e5929f57cecc7aa9a7e7c1", null ],
    [ "area", "class_voronoi_1_1_region.html#a76a1faf08926dd56e47419b0d50c1590", null ],
    [ "atomId", "class_voronoi_1_1_region.html#ac27712dca387d16bc6d8e704bffc9ecc", null ],
    [ "coords", "class_voronoi_1_1_region.html#aae1ee0e3c09095c8bc5148b64f9e5b35", null ],
    [ "is_neighbor", "class_voronoi_1_1_region.html#a3c92de6fe9a1807e4c4eb07fcdaedb66", null ],
    [ "num_edges", "class_voronoi_1_1_region.html#ac351f03a20bea627bd80be11fe616c98", null ],
    [ "num_indices", "class_voronoi_1_1_region.html#aafcf5960bdb9a77ff2f9be97f7ab70e1", null ],
    [ "print_indices", "class_voronoi_1_1_region.html#a5f2f6a5b3382dc62002058e102843119", null ],
    [ "atom", "class_voronoi_1_1_region.html#a6b45a5dc71804aeab4a0c21b95eb5e4b", null ],
    [ "edges", "class_voronoi_1_1_region.html#af593e747d3bdfad360326249c7f972af", null ],
    [ "indices", "class_voronoi_1_1_region.html#a7f3418e4d6b671ddd2e96c8c18429d46", null ],
    [ "vertices", "class_voronoi_1_1_region.html#a0ca8b05c3514a72915cb49b3375bba6c", null ]
];