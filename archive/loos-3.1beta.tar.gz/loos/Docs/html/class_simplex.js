var class_simplex =
[
    [ "Simplex", "class_simplex.html#a601c9813ea68bf4f50d53b7b830187f4", null ],
    [ "dim", "class_simplex.html#ae0b5c2fd2cafa9e37d2134e156945778", null ],
    [ "finalParameters", "class_simplex.html#a7efea748f20ecfd0eb8eee95405de419", null ],
    [ "finalValue", "class_simplex.html#a28b317fcb6bbb7693a898700622be64d", null ],
    [ "maximumIterations", "class_simplex.html#a58597f6b3bb4a373fcaf57ded0058a96", null ],
    [ "maximumIterations", "class_simplex.html#ac257ad17a8238bd348c1675af20f8793", null ],
    [ "numberOfIterations", "class_simplex.html#a1e05f74e0bf5b6c708afcf0c330c96b9", null ],
    [ "optimize", "class_simplex.html#acc22b6d14264974abb7d0f1691882f25", null ],
    [ "seedLengths", "class_simplex.html#acef9d6cf7327843c9922ae24475a8d3d", null ],
    [ "tolerance", "class_simplex.html#a6462c27e9b9b59757187b821ba012a37", null ]
];