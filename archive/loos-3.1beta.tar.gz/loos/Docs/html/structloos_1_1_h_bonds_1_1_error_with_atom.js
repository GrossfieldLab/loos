var structloos_1_1_h_bonds_1_1_error_with_atom =
[
    [ "ErrorWithAtom", "structloos_1_1_h_bonds_1_1_error_with_atom.html#a333bb42b2d5c53ad7dd5fa0d96fba0a2", null ],
    [ "~ErrorWithAtom", "structloos_1_1_h_bonds_1_1_error_with_atom.html#a03820619ad74e299575a84c75dc9ace0", null ],
    [ "what", "structloos_1_1_h_bonds_1_1_error_with_atom.html#ac270ebef604683a29bfb0392c7936e32", null ],
    [ "_msg", "structloos_1_1_h_bonds_1_1_error_with_atom.html#a23dfb48c939d20293fa2dd94e64f7466", null ]
];