var classloos_1_1internal_1_1_atomic_number_deducer =
[
    [ "AtomicNumberDeducer", "classloos_1_1internal_1_1_atomic_number_deducer.html#abadfd0546a6454dec814bd77cae07f90", null ],
    [ "deduceFromMass", "classloos_1_1internal_1_1_atomic_number_deducer.html#ab9f6b2e02a4a6aac38831da03396975f", null ]
];