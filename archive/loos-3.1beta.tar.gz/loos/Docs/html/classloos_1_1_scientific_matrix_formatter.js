var classloos_1_1_scientific_matrix_formatter =
[
    [ "ScientificMatrixFormatter", "classloos_1_1_scientific_matrix_formatter.html#a4db073a44931ebce50ca08d6c64acc05", null ],
    [ "ScientificMatrixFormatter", "classloos_1_1_scientific_matrix_formatter.html#aa37397522ee4f9e8a4bb5f007b6c648f", null ],
    [ "operator()", "classloos_1_1_scientific_matrix_formatter.html#a183aa5da5fe41554b171ff38e3060971", null ]
];