var structloos_1_1internal_1_1_value =
[
    [ "ValueType", "structloos_1_1internal_1_1_value.html#a9830c8a57f9f68c52d00328d70bdb0cc", [
      [ "NONE", "structloos_1_1internal_1_1_value.html#a9830c8a57f9f68c52d00328d70bdb0cca9f60b466173bd41baa7389311b5a84d4", null ],
      [ "STRING", "structloos_1_1internal_1_1_value.html#a9830c8a57f9f68c52d00328d70bdb0cca2ca085369aa11b1ae28fe7f137050a21", null ],
      [ "INT", "structloos_1_1internal_1_1_value.html#a9830c8a57f9f68c52d00328d70bdb0cca7bd71f821100bdc8516e6247048661e4", null ],
      [ "FLOAT", "structloos_1_1internal_1_1_value.html#a9830c8a57f9f68c52d00328d70bdb0cca73c0beef6cd8ff87d282086280ad9730", null ]
    ] ],
    [ "Value", "structloos_1_1internal_1_1_value.html#a6621eb22695069278d9e4d982cecd8cd", null ],
    [ "~Value", "structloos_1_1internal_1_1_value.html#a0b3bd86dfb52179ce1f39e9124107349", null ],
    [ "Value", "structloos_1_1internal_1_1_value.html#a7a00326a4633dfa61c2dea9e0d214093", null ],
    [ "Value", "structloos_1_1internal_1_1_value.html#abcc8e0689d2a4fbedb06ae7ffd77fcd0", null ],
    [ "Value", "structloos_1_1internal_1_1_value.html#a49f4d681fa11d118df85cfcc8ed77f3e", null ],
    [ "Value", "structloos_1_1internal_1_1_value.html#aef8a5c7a760a260ccf6162734e5e6c80", null ],
    [ "Value", "structloos_1_1internal_1_1_value.html#a0da92d883f577bc7c09307f60446339a", null ],
    [ "copy", "structloos_1_1internal_1_1_value.html#a4441b18d517aa975244d7907d0018101", null ],
    [ "getFloat", "structloos_1_1internal_1_1_value.html#ae8a1f162a1c542b3d1ee054d62d673af", null ],
    [ "getInt", "structloos_1_1internal_1_1_value.html#a7fe73dc8054184ead1f40cd91ba7477a", null ],
    [ "getString", "structloos_1_1internal_1_1_value.html#abd7d41ba0eb37ede19a9c3731e18b065", null ],
    [ "operator=", "structloos_1_1internal_1_1_value.html#ab3f0b6aec482d2f66819cc8e0365b52b", null ],
    [ "setFloat", "structloos_1_1internal_1_1_value.html#ac794534b6c384b5b312bbb3d77637c76", null ],
    [ "setInt", "structloos_1_1internal_1_1_value.html#abdc570fdc934e2cb4b329c26b9643cc4", null ],
    [ "setString", "structloos_1_1internal_1_1_value.html#a08ad447b48fd5c7393d3ed253875c9a2", null ],
    [ "operator<<", "structloos_1_1internal_1_1_value.html#ad29db86c4a2dec5bc8d0006031b07211", null ],
    [ "flt", "structloos_1_1internal_1_1_value.html#abd20cf9b7a19d628742c77eda4027d62", null ],
    [ "itg", "structloos_1_1internal_1_1_value.html#a441acaf33d55fc20ce098d73831bb685", null ],
    [ "str", "structloos_1_1internal_1_1_value.html#a67ccf95bdec787ecf773e893cb680e45", null ],
    [ "type", "structloos_1_1internal_1_1_value.html#a14c675786e2c11989a4dec6290dd0748", null ]
];