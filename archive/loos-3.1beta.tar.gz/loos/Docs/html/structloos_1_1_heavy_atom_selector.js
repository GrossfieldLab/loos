var structloos_1_1_heavy_atom_selector =
[
    [ "HeavyAtomSelector", "structloos_1_1_heavy_atom_selector.html#a97bc89253eb5bdcb9c48e22415b8059e", null ],
    [ "operator()", "structloos_1_1_heavy_atom_selector.html#ac45bc0c425a4f8958e278a862d035633", null ],
    [ "hsel", "structloos_1_1_heavy_atom_selector.html#ab90b267883ec9c4a1c6e4a5433a24c8f", null ],
    [ "not_heavy", "structloos_1_1_heavy_atom_selector.html#a771e038d604549a97a583be29976f3d8", null ]
];