var struct_sort_datum =
[
    [ "SortDatum", "struct_sort_datum.html#ad81359ea7dcbb0286f5621f52e7b1eb1", null ],
    [ "SortDatum", "struct_sort_datum.html#a9a7215aed2a040f7e8389e2204f04458", null ],
    [ "n", "struct_sort_datum.html#a6ea910bfd19bd33eb92e2cc6bcb0f441", null ],
    [ "s", "struct_sort_datum.html#ad5a6d27222e5fdcc252060ee909fa4c8", null ]
];