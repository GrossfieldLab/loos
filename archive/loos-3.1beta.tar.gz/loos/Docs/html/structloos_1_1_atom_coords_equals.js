var structloos_1_1_atom_coords_equals =
[
    [ "AtomCoordsEquals", "structloos_1_1_atom_coords_equals.html#ad2fb79d053588bf66207bf99edc57b1a", null ],
    [ "AtomCoordsEquals", "structloos_1_1_atom_coords_equals.html#ad328324792018ad1969776f348da1355", null ],
    [ "operator()", "structloos_1_1_atom_coords_equals.html#ab6d89940d26332a4cbf59c262dcc033a", null ],
    [ "threshold", "structloos_1_1_atom_coords_equals.html#a277d0cbfa1d5849ab59ae5636f662c3a", null ]
];