var classloos_1_1_amber_traj =
[
    [ "AmberTraj", "classloos_1_1_amber_traj.html#ab6642733b93e29fe28993eed8bf26252", null ],
    [ "AmberTraj", "classloos_1_1_amber_traj.html#ae9fe5ead06f7fadd15d4d6c9e61d4694", null ],
    [ "coords", "classloos_1_1_amber_traj.html#a735ddcd666ef052238058977bd3a8cc6", null ],
    [ "description", "classloos_1_1_amber_traj.html#aa508fa6bf1cf158a24a2f29f74d1de32", null ],
    [ "hasPeriodicBox", "classloos_1_1_amber_traj.html#a57f9141236f6dc8d5155cd7effd0a2a6", null ],
    [ "natoms", "classloos_1_1_amber_traj.html#a9492f62ead736f82eb113371b6ad7ae1", null ],
    [ "nframes", "classloos_1_1_amber_traj.html#aea715a2cca7797f4b821250bab8450ab", null ],
    [ "parseFrame", "classloos_1_1_amber_traj.html#a15e853b1947916cb7c71495c87ac1b61", null ],
    [ "periodicBox", "classloos_1_1_amber_traj.html#ae40944ec24208032928e4f2451c6cefb", null ],
    [ "timestep", "classloos_1_1_amber_traj.html#a89d33746e84e3dabe49f1412fefac521", null ],
    [ "velocityConversionFactor", "classloos_1_1_amber_traj.html#a37d0a6fd8aea0a3bdf9e3645e8ce4d51", null ]
];