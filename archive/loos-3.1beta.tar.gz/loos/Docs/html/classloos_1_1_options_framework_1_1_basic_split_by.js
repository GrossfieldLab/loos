var classloos_1_1_options_framework_1_1_basic_split_by =
[
    [ "SplitType", "classloos_1_1_options_framework_1_1_basic_split_by.html#a2e80b87da8dde781d7aeaec697272e74", [
      [ "NONE", "classloos_1_1_options_framework_1_1_basic_split_by.html#a2e80b87da8dde781d7aeaec697272e74a17d88cf861fbf5c8a1579c0ec7cc81fd", null ],
      [ "MOLECULE", "classloos_1_1_options_framework_1_1_basic_split_by.html#a2e80b87da8dde781d7aeaec697272e74ab27cde86b16009737c6debe14dbd480f", null ],
      [ "SEGID", "classloos_1_1_options_framework_1_1_basic_split_by.html#a2e80b87da8dde781d7aeaec697272e74a25c135a8b9361a184d2b46910babf9e1", null ],
      [ "RESIDUE", "classloos_1_1_options_framework_1_1_basic_split_by.html#a2e80b87da8dde781d7aeaec697272e74ac7d5f945a9efc2fc82d028d98a0555fd", null ]
    ] ],
    [ "BasicSplitBy", "classloos_1_1_options_framework_1_1_basic_split_by.html#aa6661939854793b5157debc2b28e5ed6", null ],
    [ "BasicSplitBy", "classloos_1_1_options_framework_1_1_basic_split_by.html#a98db1c5491b8b7d6ca8149b3091b566c", null ],
    [ "BasicSplitBy", "classloos_1_1_options_framework_1_1_basic_split_by.html#a55784b068b7c27094668ed843ca4f3ee", null ],
    [ "split", "classloos_1_1_options_framework_1_1_basic_split_by.html#a18b5cdfe11296949653afdb9c2306173", null ],
    [ "label", "classloos_1_1_options_framework_1_1_basic_split_by.html#a48ed5716741e9cadb3f9eac6e760eaca", null ],
    [ "split_method", "classloos_1_1_options_framework_1_1_basic_split_by.html#a6b6c55e6bcaaa6356d5f0fa80201c6e0", null ],
    [ "split_type", "classloos_1_1_options_framework_1_1_basic_split_by.html#a728d72be80034d2be372cdd2e143a015", null ]
];