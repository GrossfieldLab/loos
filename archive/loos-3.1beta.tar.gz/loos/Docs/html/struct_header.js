var struct_header =
[
    [ "box", "struct_header.html#aaf3f30d29d71e44bf298dc65ae026792", null ],
    [ "natoms", "struct_header.html#a8be9d1e16689735e00814351b4ccf660", null ],
    [ "step", "struct_header.html#af73cd1579b541a98d564dd71c2a377af", null ],
    [ "time", "struct_header.html#a6d59a9babcc6f41ed113bdf1641fc1a8", null ]
];