var classloos_1_1_estimating_counter =
[
    [ "EstimatingCounter", "classloos_1_1_estimating_counter.html#af514e7b7026ac16bedb15a8f139f5743", null ],
    [ "fractionComplete", "classloos_1_1_estimating_counter.html#af8d78e663f891ff17c30e44155b6b008", null ],
    [ "remaining", "classloos_1_1_estimating_counter.html#a4c6ed55234efeac2e348c38115c35082", null ],
    [ "setExpected", "classloos_1_1_estimating_counter.html#a2b28cfdc62d2cb02e66001c5f53e33a1", null ],
    [ "timeRemaining", "classloos_1_1_estimating_counter.html#afc2041411f0cda5988155f1d7dfc9070", null ],
    [ "expected", "classloos_1_1_estimating_counter.html#ad7e003893c2447b624f35a7653e20ddb", null ]
];