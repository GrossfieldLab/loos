var classpacking__score__per__res_1_1_full_help =
[
    [ "__init__", "classpacking__score__per__res_1_1_full_help.html#ac38a747884ec36ab624815f64dc9720b", null ],
    [ "__call__", "classpacking__score__per__res_1_1_full_help.html#ac06152fd25f0ab14a1f486bd06dcdb1f", null ]
];