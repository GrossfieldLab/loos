var classloos_1_1_backbone_selector =
[
    [ "operator()", "classloos_1_1_backbone_selector.html#ae500b10d1f844c57211b9223792dc638", null ]
];