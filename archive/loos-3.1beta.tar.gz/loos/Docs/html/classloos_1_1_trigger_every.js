var classloos_1_1_trigger_every =
[
    [ "TriggerEvery", "classloos_1_1_trigger_every.html#ae499756b7a88669a2d22295efe926488", null ],
    [ "operator()", "classloos_1_1_trigger_every.html#ae310cfc2707b940bd069239d0e499260", null ],
    [ "setFrequency", "classloos_1_1_trigger_every.html#a7f310ee91c178a28493939224f52f9b7", null ]
];