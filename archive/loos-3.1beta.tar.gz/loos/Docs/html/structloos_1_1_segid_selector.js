var structloos_1_1_segid_selector =
[
    [ "SegidSelector", "structloos_1_1_segid_selector.html#ac831fbcee8fc183a6c484d58b7cf21ae", null ],
    [ "operator()", "structloos_1_1_segid_selector.html#a258aafb9827306727649d11a428c9c4f", null ],
    [ "str", "structloos_1_1_segid_selector.html#a830facaf89445eb52d2bd994e39bc0ca", null ]
];