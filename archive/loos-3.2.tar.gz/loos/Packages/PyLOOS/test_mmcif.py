#!/usr/bin/env python3

import loos

mmcif_filename = "/Users/agrossfield/Downloads/1u19.cif"
mmcif = loos.MMCIF(mmcif_filename)

print(mmcif.unitCell())
print(mmcif.periodicBox())

mmcif2 = loos.createSystem(mmcif_filename)
print(mmcif2[0])


sys3 = loos.createSystem("/Users/agrossfield/Downloads/1u19.pdbx")
print(sys3.periodicBox())
