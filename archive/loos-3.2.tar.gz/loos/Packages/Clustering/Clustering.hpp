#if !defined(LOOS_CLUSTER_HPP)
#define LOOS_CLUSTER_HPP
// include this header if you want the entire NS, for tools.
#include "ClusteringTypedefs.hpp"
#include "ClusteringUtils.hpp"
#include "HAC.hpp"
#include "AverageLinkage.hpp"
#include "KGS.hpp"

#endif
